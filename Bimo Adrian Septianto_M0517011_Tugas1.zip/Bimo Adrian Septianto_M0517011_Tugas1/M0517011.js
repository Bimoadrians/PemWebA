function showMessage() {
    var message = document.getElementById("message").value;
    display_message.innerHTML= message;
    var username = document.getElementById("username").value;
    display_username.innerHTML= username;
    var email = document.getElementById("email").value;
    display_email.innerHTML= email;

}

/* Toggle between adding and removing the "responsive" class to topnav when the user clicks on the icon */
function myFunction() {
  var x = document.getElementById("myTopnav");
  if (x.className === "topnav") {
    x.className += " responsive";
} else {
    x.className = "topnav";
}
}

var inactivityTime = function () {
    var time;
    window.onload = resetTimer;
    document.onmousemove = resetTimer;
    document.onkeypress = resetTimer;

    function message() {
        alert("You are now idle.");
        //location.href = 'logout.html'
    }

    function resetTimer() {
        clearTimeout(time);
        time = setTimeout(message, 30000);
        // 1000 milliseconds = 1 second
    }
};